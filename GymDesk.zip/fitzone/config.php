<?php

//connection database
$conn = mysqli_connect('localhost','root','','fitzone');

?>